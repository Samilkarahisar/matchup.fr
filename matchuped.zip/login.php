<html>
  
<head><meta http-equiv="Content-Type" content="text/HTML; charset=utf-8" />
<title>Yazar girişi.</title>

<style>
body{
background-color: #f1f1f1;
}

#merkez{
width:250px;
height:300px;
margin:auto;
}

input:focus {outline: none; }

.textbox{
border: 0px;
padding-left:25px;
width: 230px;
height:50px;
font-size:15px;

background-color: white;
}

#tcontain{
padding-left:8px;
margin-top:3px;
}
.myButton {
width: 230px;
	-moz-box-shadow:inset 0px 1px 0px 0px #ff4000;
	-webkit-box-shadow:inset 0px 1px 0px 0px #ff4000;
	box-shadow:inset 0px 1px 0px 0px #ff4000;
	background-color:#ff2828;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:2px;
	border:none;
	display:inline-block;
	cursor:pointer;
	color:#f1f1f1;
	font-family:Arial;
	font-size:13px;
	font-weight:bold;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #854629;
}

.myButton:active {
	position:relative;
	top:1px;
}


#logo{
margin:auto;
 height: auto; 
    width: auto; 
    max-width: 78x; 
    max-height: 21px;
}
img{
max-width:100%;
max-height:100%;
}
</style>
</head>
  
<body>
<center>
<?php
if (!$hata =="") {
echo '<font face="verdana" size="2" color="#800000"><b>Giri&#351; S&#305;ras&#305;nda Hata Olu&#351;tu</b><br>';
echo '&#350;ifre veya Kullan&#305;c&#305; Ad&#305; Yanl&#305;&#351;. Tekrar Deneyin<br>';
}
?>
</center>

<center>
<div id="logo">
<img src="nessir.png"/>
</div>

</center>
<div id="merkez">
<form action="login_done.php" method="post">

<div id="tcontain">
<input class="textbox" type="text" name="kullaniciadi" size="25" required placeholder="Kalem ismi" autocomplete="off">
<input class="textbox" type="password" name="sifre" size="25" required placeholder="Şifre" autocomplete="off">
<input class="myButton" type="submit" value="Giriş yap">
</div>



</form>
</div>

</body>
  
</html>