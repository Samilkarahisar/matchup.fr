<?php
session_start();

if(isset($_SESSION['utaken'])){

$errormessage= $_SESSION['utaken'];
session_destroy();
}

include("db_settings.php");

$sql= $conn->query("SELECT * FROM uye");

$total = $sql->num_rows;

$left = 200 - $total;

?>

<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Roboto:900' rel='stylesheet' type='text/css'>
<meta http-equiv="Content-Type" content="text/HTML; charset=utf-8" />
<title>Hulpar - Kayıt</title>

<style>

body{
background-color: #f1f1f1;

}

#merkez{
width:250px;
height:300px;
margin:auto;
}
input:focus {outline: none; }
span{
font-family: 'Roboto', sans-serif;
color:white;
 font-size:16px;
}
#forspan{
margin-bottom:20px;
}
#ermes{
font-family: 'Roboto', sans-serif;
color:red;
font-size:13px;
}
.textbox{
padding-left:25px;
border:none;
width: 230px;
height:50px;
font-size:15px;
}

#tcontain{
background: none;
margin-top:5px;
padding-left:8px;
}

.btn {
width:230px;
   
    	-moz-box-shadow:inset 0px 1px 0px 0px #a812e8;
	-webkit-box-shadow:inset 0px 1px 0px 0px #a812e8;
	box-shadow:inset 0px 1px 0px 0px #a812e8;
	background-color:#590c7a;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:3px;
	border:1px solid #4d004d;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:13px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #7a0d76;
}

.btn:hover {
   
	background-color:#5c02a6;
}

.btn:active {
	position:relative;
	top:1px;
}





#logo{
margin-top:100px;
margin:auto;
 height: auto; 
    width: auto; 
    max-width: 78x; 
    max-height: 21px;
}
img{
max-width:100%;
max-height:100%;
}

#forlogin{
font-family: 'Roboto', sans-serif;
margin-bottom:20px;

}

.myButton {
width: 230px;
	-moz-box-shadow:inset 0px 1px 0px 0px #ff4000;
	-webkit-box-shadow:inset 0px 1px 0px 0px #ff4000;
	box-shadow:inset 0px 1px 0px 0px #ff4000;
	background-color:#ff2828;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:2px;
	border:none;
	display:inline-block;
	cursor:pointer;
	color:#f1f1f1;
	font-family:Arial;
	font-size:13px;
	font-weight:bold;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #854629;
}

.myButton:active {
	position:relative;
	top:1px;
}

</style>
</head>



<body>
<center>
<div id="logo">
<img src="nessir.png"/>
</div>

</center>

<div id="merkez">
<form action="register_done.php" method="post">

<div id="tcontain">

<input class="textbox" type="text" name="ad" id="ad" size="25" required placeholder="İsim" autocomplete="off">
<input class="textbox" type="text" name="kullaniciadi" id="kullaniciadi" size="25" required placeholder="Kalem ismi" autocomplete="off">
<input class="textbox" type="password" name="sifre" id="sifre" size="25" required placeholder="Şifre" autocomplete="off">
<input class="myButton" type="submit" value="Register" name="B1">

</div>
<center>
<div  id="ermes">
<?php echo $errormessage;?> 
</div>

</center>



</form>
</div>




<center>




<div id="forlogin">
<center>
<span><a href="http://matchup.fr/login.php" CLASS="Button"> Kayıtlıyım. </a> </span>
</center>
</div>

</center>


</body>
</html>