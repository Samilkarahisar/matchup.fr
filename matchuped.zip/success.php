<?php
echo "Votre matchup a été crée. Vous allez etre redirigé." ;

sleep(5);

header("Location: http://matchup.fr/feed.php");

?>