<?php 
header("Location: http://matchup.fr/feed.php");
exit;


?>