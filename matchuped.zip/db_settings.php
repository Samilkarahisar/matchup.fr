<?php
$host = "localhost";
$mysqladi = "a6110619_samil";
$mysqlsifre ="Asbusa19071453";
$db = "a6110619_users";

$conn = new mysqli($host, $mysqladi, $mysqlsifre,$db);
?>